CRYPT 2.1-SNAPSHOT README

    This is the 2.1-SNAPSHOT release of the VT Crypt Java libraries.
    It is licensed under the LGPL.
    If you have questions or comments about this library contact
    Middleware Services (middleware@vt.edu).

DOCUMENTATION
    See the wiki: http://code.google.com/p/vt-middleware/wiki/vtcrypt

