/*
  $Id: EncryptMojoTest.java 693 2009-09-30 15:30:46Z marvin.addison $

  Copyright (C) 2007-2009 Virginia Tech
  All rights reserved.

  SEE LICENSE FOR MORE INFORMATION

  Author:  Marvin S. Addison
  Email:   serac@vt.edu
  Version: $Revision: 693 $
  Updated: $Date: 2009-09-30 11:30:46 -0400 (Wed, 30 Sep 2009) $
*/
package edu.vt.middleware.crypt.maven;

import java.io.File;

import org.apache.maven.plugin.testing.AbstractMojoTestCase;

/**
 * Test class for <code>EncryptMojo</code>.
 * @author Marvin S. Addison
 * @version $Revision: 693 $
 *
 */
public class EncryptMojoTest extends AbstractMojoTestCase
{
  /** Test ciphertext corresponding to plaintext (using test.key) */
  private static final String TEST_CIPHERTEXT = "Hpvc/gZ/1DGqG0dzIeNlvw==";

  /**
   * {@inheritDoc}
   */
  protected void setUp() throws Exception
  {
    // required for mojo lookups to work
    super.setUp();
  }

  /**
   * Tests the encryption mojo.
   *
   * @throws Exception On any error.
   */
  public void testEncrypt() throws Exception
  {
    final File testPom = getTestFile("src/test/resources/encrypt-test.xml");
    final EncryptMojo mojo = (EncryptMojo) lookupMojo("encrypt", testPom);
    assertNotNull(mojo);
    mojo.execute();
    assertEquals(TEST_CIPHERTEXT, mojo.getCipherText());
  }
}
