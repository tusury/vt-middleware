/*
  $Id: GenkeyMojoTest.java 693 2009-09-30 15:30:46Z marvin.addison $

  Copyright (C) 2007-2009 Virginia Tech
  All rights reserved.

  SEE LICENSE FOR MORE INFORMATION

  Author:  Marvin S. Addison
  Email:   serac@vt.edu
  Version: $Revision: 693 $
  Updated: $Date: 2009-09-30 11:30:46 -0400 (Wed, 30 Sep 2009) $
*/
package edu.vt.middleware.crypt.maven;

import java.io.File;

import org.apache.maven.plugin.testing.AbstractMojoTestCase;

/**
 * Test class for <code>GenkeyMojo</code>.
 * @author Marvin S. Addison
 * @version $Revision: 693 $
 *
 */
public class GenkeyMojoTest extends AbstractMojoTestCase
{
  /** Test path to key file*/
  private static final String TEST_KEYFILE_PATH = "target/test.key";

  /**
   * {@inheritDoc}
   */
  protected void setUp() throws Exception
  {
    // required for mojo lookups to work
    super.setUp();
  }

  /**
   * Tests the key generation mojo.
   *
   * @throws Exception On any error.
   */
  public void testGenkey() throws Exception
  {
    final File testPom = getTestFile("src/test/resources/genkey-test.xml");
    final GenkeyMojo mojo = (GenkeyMojo) lookupMojo("genkey", testPom);
    assertNotNull(mojo);
    mojo.execute();
    final File keyFile = getTestFile(TEST_KEYFILE_PATH);
    assertTrue(keyFile.exists());
  }
}
